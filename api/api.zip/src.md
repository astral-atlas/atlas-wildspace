# Contributing to @astral-atlas/wildspace-api

## New Features/Integration/External Network Requests
folders: `[src/services]`

Consider first creating a *service*, that lives inside the services folder.

## Endpoints, formats, response structure
folders: `[src/routes]`
